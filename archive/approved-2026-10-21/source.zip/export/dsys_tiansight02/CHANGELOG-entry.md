## v0.7 · 2026-10-20 · 餐饮展陈与厨房设计

- New deliverable `deliverables/exhibit-design/` (41 pages, 1280×720): offline `index.html` plus DC source in `src/`.
- Chapters renamed to owner outcomes: 让顾客愿意点 · 让招牌菜卖上价 · 让高峰出得快 · 让方案落得了地 · 让改善看得见; entry page 展陈诊断 (four steps, three deliverables).
- 边江's brief line aligned with the v0.7 ruling: 前海底捞品牌负责人.
- Pages marked `hold` in `slide-catalog.js` await licence or authorisation (partner logos, hotel marks, 游园京梦 photos); see the deliverable README.
- Follow-up: refresh `TIANSIGHT 侍天 Design System/` to the e0a760 export so `src/` runs from the repo.
