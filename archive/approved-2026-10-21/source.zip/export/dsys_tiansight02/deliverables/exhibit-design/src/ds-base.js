// Loads the 侍天 TIANSIGHT design-system bundle (namespace TIANSIGHTDesignSystem_e0a760).
// In dsys_tiansight02 the bundle lives at the repo root in "TIANSIGHT 侍天 Design System/".
// That folder must carry the e0a760 export (see ../README.md); the older bb63dc export lacks the slide components.
(() => {
  const base = '../../../TIANSIGHT 侍天 Design System';
  const l = document.createElement('link');
  l.rel = 'stylesheet'; l.href = base + '/styles.css';
  document.head.appendChild(l);
  const s = document.createElement('script');
  s.src = base + '/_ds_bundle.js';
  s.onerror = () => console.error('ds-base.js: failed to load ' + s.src);
  document.head.appendChild(s);
})();
