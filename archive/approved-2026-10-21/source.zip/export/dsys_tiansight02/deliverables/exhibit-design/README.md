# 侍天 TIANSIGHT 餐饮展陈与厨房设计（41 页）

16:9 演示文稿，1280×720，基于设计系统幻灯片组件（`TIANSIGHTDesignSystem_e0a760.*Slide`）。

| 文件 | 内容 |
|---|---|
| `index.html` | 离线单文件版（字体、图片、组件全部内嵌），直接打开即可翻页、打印 PDF |
| `src/TiansightDeck-Exhibit.dc.html` | 源文件：页序与文案在 `renderVals()`，每页一条 `add(...)` |
| `src/content/` | `team.js` 团队 · `contact.js` 联系页 · `slide-catalog.js` 每页永久 id、分类、发布状态 |
| `src/exhibit/` | 本文稿用到的图片（仅已引用的 22 张）；人像、二维码、印章取自设计系统 `assets/` |
| `src/ds-base.js` | 指向仓库根目录 `TIANSIGHT 侍天 Design System/` |

## 结构

封面 → 主张 → 问题 → 菜单驱动 → 一 让顾客愿意点 → 二 让招牌菜卖上价 → 三 让高峰出得快 → 四 让方案落得了地 → 五 让改善看得见 → 团队 → 展陈诊断（合作入口） → 联系。

开关（props）：`showBenchmarks` 国际研究成效页 · `showSupply` 设备合作方四页 · `showTeam` 团队五页。

## 源文件运行条件

仓库中 `TIANSIGHT 侍天 Design System/_ds_bundle.js` 当前为 `TIANSIGHTDesignSystem_bb63dc`，不含 `MatrixTableSlide`、`StatColumnsSlide`、`ScreensSlide`、`ModuleDetailSlide`、`CardGridSlide`、`SlideFrame`。`src/` 需用设计系统 artifact 的 e0a760 导出更新该文件夹后才能运行；在此之前以 `index.html` 为准。

## 发布状态（slide-catalog.js 中 `publish: "hold"`）

| 页 | 待确认 |
|---|---|
| 光与视觉 · 光与视觉 · 成效 | 研究数字对照原文（Buell、Wansink） |
| 全线配套 | 设备品牌 logo 使用许可 |
| 服务经历 | 酒店集团商标使用 |
| 服务品牌 | 品牌墙名称由余向东核对 |
| 项目案例 · 游园京梦 一、二 | 实景照片的品牌方授权 |
| 展陈诊断 | 交付数量（1 份 · 3 项 · 1 套） |

按 `docs/maintaining.md` §6，上述授权确认前，相关图片（`exhibit/case/*`、`exhibit/hotels.jpg`、`exhibit/brand-wall.jpg`、`exhibit/src/p9-1.jpg`）及内嵌这些图片的 `index.html` 不应推送到公开仓库。
